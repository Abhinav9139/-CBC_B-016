export type Unit = 'imperial' | 'metric' | 'standard'
export interface Coordinate {
    lon: number;
    lat: number;
}