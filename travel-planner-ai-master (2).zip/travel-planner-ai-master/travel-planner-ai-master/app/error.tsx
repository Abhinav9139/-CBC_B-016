"use client";
const Error = () => {
  return <div>Something went extremely wrong!</div>;
};

export default Error;
