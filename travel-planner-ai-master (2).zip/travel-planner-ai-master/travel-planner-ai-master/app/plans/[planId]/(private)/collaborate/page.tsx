import Collaborator from "@/components/settings/Collaborator";

export default function Collaborate({params: {planId}}: {params: {planId: string}}) {
  return <Collaborator />;
}
